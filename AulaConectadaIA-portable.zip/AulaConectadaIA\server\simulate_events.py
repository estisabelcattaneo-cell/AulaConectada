from __future__ import annotations

import json
import random
import time
import urllib.request


API_BASE_URL = "http://localhost:8080"
GATEWAY_ID = "ESP32-AULA-10"

STUDENTS = [
    ("EST-001", "Ana Sofia Banqueth Arias"),
    ("EST-002", "Isabel Sofia Caitaneo Contreras"),
    ("EST-003", "Adriana Moreno Hurtado"),
    ("EST-004", "Alejandro Martinez Machecha"),
    ("EST-005", "Greysis Nicole Torres Alvarado"),
]


def post(path: str, payload: dict) -> None:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        API_BASE_URL + path,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        print(response.status, response.read().decode("utf-8"))


def get(path: str) -> dict:
    with urllib.request.urlopen(API_BASE_URL + path, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


def status_from_rssi(rssi: int) -> tuple[str, float]:
    if rssi >= -68:
        return "Presente en clase", 0.92
    if rssi >= -84:
        return "En zonas comunes", 0.68
    return "Ausente", 0.35


def main() -> None:
    settings = get("/api/settings")
    zone = settings.get("active_classroom", "Aula 10")

    post(
        "/api/heartbeat",
        {
            "gateway_id": GATEWAY_ID,
            "zone": zone,
            "ip": "192.168.1.50",
            "wifi_rssi": -47,
            "firmware_version": "simulador",
        },
    )

    for student_id, name in STUDENTS:
        rssi = random.choice([-58, -62, -66, -72, -80, -91])
        status, confidence = status_from_rssi(rssi)
        post(
            "/api/events",
            {
                "student_id": student_id,
                "student_name": name,
                "status": status,
                "zone": zone,
                "rssi": rssi,
                "confidence": confidence,
                "source": "Simulador BLE",
                "gateway_id": GATEWAY_ID,
            },
        )
        time.sleep(0.5)


if __name__ == "__main__":
    main()
