@echo off
setlocal
cd /d "%~dp0"

call "%~dp0tools\find_python.cmd"
if errorlevel 1 (
  pause
  exit /b 1
)

echo.
echo Iniciando AulaConectada IA...
echo Panel local: http://localhost:8080
echo Para detener el servidor, cierra esta ventana o presiona Ctrl+C.
echo.

start "" "http://localhost:8080"
"%PYTHON_EXE%" server\app.py
pause
