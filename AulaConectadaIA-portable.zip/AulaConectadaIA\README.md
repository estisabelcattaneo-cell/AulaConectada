# AulaConectada IA

Sistema inteligente de presencia y geolocalizacion escolar mediante IoT.

Este repositorio contiene la parte practica del proyecto:

- Firmware para ESP32 con escaneo BLE.
- Servidor local con API REST y base de datos SQLite.
- Panel web para visualizar asistencia en tiempo real.
- Gestion de aulas desde el panel.
- Simulador para probar el sistema sin hardware.
- Guia de montaje y validacion.

## Arquitectura

```mermaid
flowchart LR
  B[Beacon BLE del estudiante] --> E[ESP32 en el aula]
  E -->|HTTP JSON| S[Servidor AulaConectada]
  S --> DB[(SQLite)]
  S --> P[Panel web]
```

## Requisitos

### Hardware

- 1 ESP32 NodeMCU.
- 1 LED RGB o LED sencillo.
- 1 buzzer activo de 5V o 3.3V.
- Protoboard y cables Dupont.
- Fuente 5V 2A.
- Opcional: pantalla LCD 16x2 I2C.
- Beacons BLE o celulares configurados como emisores BLE.

### Software

- Python 3.
- Arduino IDE.
- Soporte de placas ESP32 instalado en Arduino IDE.

## Ejecutar el servidor

Desde la carpeta del proyecto:

```powershell
python server\app.py
```

En Windows tambien puedes usar:

```text
INICIAR_AULACONECTADA.cmd
```

Abre el panel en:

```text
http://localhost:8080
```

## Probar sin ESP32

Con el servidor encendido, ejecuta:

```powershell
python server\simulate_events.py
```

El panel debe mostrar estudiantes, detecciones, estado del gateway y resumen de presentes/ausentes.

## Cambiar el aula activa

Desde el panel web, usa la seccion `Aula activa`.

- Selecciona un aula existente y presiona `Aplicar aula`.
- Escribe un aula nueva y presiona `Crear y aplicar`.

El ESP32 consulta la ruta `/api/settings` para leer el aula activa y enviar sus eventos a esa zona.

## Configurar el firmware

Abre `firmware/aulaconectada_esp32/aulaconectada_esp32.ino` en Arduino IDE y cambia:

```cpp
const char* WIFI_SSID = "CAMBIAR_NOMBRE_WIFI";
const char* WIFI_PASSWORD = "CAMBIAR_CLAVE_WIFI";
const char* API_BASE_URL = "http://192.168.1.50:8080";
```

`API_BASE_URL` debe apuntar a la IP del computador donde corre el servidor. En Windows puedes consultarla con:

```powershell
ipconfig
```

## Pines sugeridos

| Componente | Pin ESP32 |
|---|---:|
| LED | GPIO 2 |
| Buzzer | GPIO 15 |
| GND comun | GND |

Si usas LCD I2C:

| LCD I2C | ESP32 |
|---|---:|
| SDA | GPIO 21 |
| SCL | GPIO 22 |
| VCC | 5V |
| GND | GND |

## Logica de IA del prototipo

El modelo practico usa una clasificacion ligera basada en RSSI:

| RSSI BLE | Estado |
|---:|---|
| Mayor o igual a -68 dBm | Presente en clase |
| Entre -84 dBm y -69 dBm | En zonas comunes |
| Menor a -84 dBm | Ausente |

Esta regla cumple la funcion de prototipo de IA porque interpreta una señal variable, estima confianza y toma una decision automatica. Para una version posterior, puede reemplazarse por un modelo entrenado con muestras reales de RSSI, hora, aula y movimiento.

## Evidencia para exposicion

1. Encender servidor con `python server\app.py`.
2. Abrir `http://localhost:8080`.
3. Ejecutar `python server\simulate_events.py` para cargar datos de prueba.
4. Mostrar como el panel cambia el total de presentes, ausentes y zonas comunes.
5. Explicar que el ESP32 real envia el mismo JSON que el simulador.

## Estructura

```text
firmware/
  aulaconectada_esp32/
    aulaconectada_esp32.ino
server/
  app.py
  simulate_events.py
  static/
    index.html
    styles.css
    app.js
docs/
  GUIA_COMPLETA_INSTALACION_USO.md
  montaje_y_pruebas.md
tools/
  find_python.cmd
INICIAR_AULACONECTADA.cmd
SIMULAR_DATOS.cmd
ABRIR_PANEL.cmd
VER_IP_DEL_COMPUTADOR.cmd
```

## Guia completa

Consulta `docs/GUIA_COMPLETA_INSTALACION_USO.md` para instalar el proyecto en otro computador, configurar el puerto COM del ESP32, cambiar aulas y probar la API.
