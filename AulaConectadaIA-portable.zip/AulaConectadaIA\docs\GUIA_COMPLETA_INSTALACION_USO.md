# Guia completa de instalacion y uso

## 1. Que contiene el proyecto

AulaConectada IA tiene cuatro partes:

| Parte | Archivo o carpeta | Funcion |
|---|---|---|
| Servidor/API | `server/app.py` | Recibe eventos del ESP32, guarda datos y entrega informacion al panel |
| Panel web | `server/static/` | Muestra estudiantes, asistencia, gateway y aulas |
| Firmware ESP32 | `firmware/aulaconectada_esp32/` | Escanea BLE y envia eventos a la API |
| Scripts Windows | `*.cmd` | Inician la app, abren el panel y simulan datos |

No necesita una cuenta de Codex para funcionar en otro computador. Codex solo se uso para desarrollar el proyecto.

## 2. Instalar en otro computador

### Opcion recomendada: instalador

1. Copia el archivo `AulaConectadaIA-Instalador.exe` al otro computador.
2. Haz doble clic sobre el instalador.
3. El instalador copiara el sistema en:

```text
Documentos\AulaConectadaIA
```

4. Al finalizar, acepta iniciar la app o abre:

```text
Documentos\AulaConectadaIA\INICIAR_AULACONECTADA.cmd
```

### Requisito importante

El computador debe tener Python 3 instalado. Si el script dice que no encuentra Python:

1. Instala Python desde `https://www.python.org/downloads/`.
2. Durante la instalacion marca `Add Python to PATH`.
3. Cierra y vuelve a abrir la ventana.
4. Ejecuta otra vez `INICIAR_AULACONECTADA.cmd`.

## 3. Iniciar el sistema

En la carpeta del proyecto, haz doble clic en:

```text
INICIAR_AULACONECTADA.cmd
```

Se abrira el panel:

```text
http://localhost:8080
```

La ventana negra que queda abierta es el servidor. No la cierres mientras uses el sistema.

## 4. Probar sin ESP32

Con el servidor abierto, ejecuta:

```text
SIMULAR_DATOS.cmd
```

Esto envia detecciones falsas para comprobar que el panel, la API y la base de datos estan funcionando.

## 5. Cambiar aulas dentro de la app

1. Abre el panel en `http://localhost:8080`.
2. Busca la seccion `Aula activa`.
3. Para usar un aula existente, selecciona el aula y presiona `Aplicar aula`.
4. Para crear otra aula, escribe el nombre en `Nueva aula` y presiona `Crear y aplicar`.

Cuando cambias el aula activa:

- El resumen se calcula para esa aula.
- La columna `Zona esperada` de los estudiantes cambia a esa aula.
- El simulador envia datos a esa aula.
- El ESP32 real consulta `/api/settings` y toma el aula activa en el siguiente heartbeat.

## 6. Configurar la IP para el ESP32

El ESP32 no usa `localhost`, porque `localhost` en el ESP32 seria el propio ESP32. Debe usar la IP del computador donde corre el servidor.

1. Ejecuta:

```text
VER_IP_DEL_COMPUTADOR.cmd
```

2. Busca la linea `IPv4`.
3. Si la IP es, por ejemplo, `192.168.1.50`, en el firmware debes poner:

```cpp
const char* API_BASE_URL = "http://192.168.1.50:8080";
```

El computador y el ESP32 deben estar conectados a la misma red WiFi.

## 7. Configurar el puerto fisico del ESP32

1. Conecta el ESP32 al computador con un cable USB de datos.
2. Abre `Administrador de dispositivos`.
3. Entra a `Puertos (COM y LPT)`.
4. Ubica el puerto, por ejemplo `COM3`, `COM4` o `COM5`.
5. En Arduino IDE selecciona:

```text
Herramientas > Placa > ESP32 Arduino > ESP32 Dev Module
Herramientas > Puerto > COMx
```

Si no aparece el puerto, instala el driver de tu placa:

- CH340 si aparece como placa economica ESP32.
- CP210x si usa chip Silicon Labs.

## 8. Cargar el firmware al ESP32

1. Abre:

```text
firmware\aulaconectada_esp32\aulaconectada_esp32.ino
```

2. Cambia:

```cpp
const char* WIFI_SSID = "CAMBIAR_NOMBRE_WIFI";
const char* WIFI_PASSWORD = "CAMBIAR_CLAVE_WIFI";
const char* API_BASE_URL = "http://IP_DEL_COMPUTADOR:8080";
```

3. Presiona `Subir` en Arduino IDE.
4. Si aparece `Connecting...` y no avanza, mantén presionado `BOOT` en el ESP32 hasta que empiece la carga.
5. Abre el monitor serial a `115200 baudios`.

Salida esperada:

```text
Conectando WiFi...
IP asignada: 192.168.1.xx
GET http://IP_DEL_COMPUTADOR:8080/api/settings -> 200
Aula activa: Aula 10
POST http://IP_DEL_COMPUTADOR:8080/api/heartbeat -> 200
Escaneando BLE...
```

## 9. Verificar que la API recibe al ESP32

En el panel revisa la seccion `Gateway`.

Debe aparecer:

```text
ESP32-AULA-10
```

Si aparece, el ESP32 ya se esta comunicando con la API.

## 10. Notas sobre BLE

El firmware trae MAC de prueba:

```cpp
"aa:bb:cc:10:00:01"
"aa:bb:cc:10:00:02"
"aa:bb:cc:10:00:03"
"aa:bb:cc:10:00:04"
"aa:bb:cc:10:00:05"
```

Para una demostracion real es mejor usar beacons BLE configurables. Muchos celulares cambian su MAC Bluetooth por privacidad, por eso pueden fallar como identificadores fijos.

## 11. Problemas frecuentes

| Problema | Solucion |
|---|---|
| El panel no abre | Ejecuta `INICIAR_AULACONECTADA.cmd` y no cierres la ventana del servidor |
| El ESP32 no conecta a la API | Revisa que `API_BASE_URL` tenga la IP del computador, no `localhost` |
| El puerto COM no aparece | Cambia cable USB o instala driver CH340/CP210x |
| El navegador abre pero no llegan datos | Ejecuta `SIMULAR_DATOS.cmd` para separar si falla el ESP32 o el servidor |
| Otro equipo no entra por IP | Permite Python en el Firewall de Windows para redes privadas |

## 12. Presentacion del prototipo

Secuencia recomendada para exponer:

1. Abrir `INICIAR_AULACONECTADA.cmd`.
2. Mostrar el panel.
3. Cambiar o crear un aula desde `Aula activa`.
4. Ejecutar `SIMULAR_DATOS.cmd`.
5. Mostrar que cambian presentes, ausentes y zonas comunes.
6. Mostrar el firmware del ESP32 y explicar que envia los mismos datos que el simulador.
