@echo off
echo.
echo Busca la linea "IPv4" del adaptador WiFi o Ethernet conectado.
echo Esa IP se usa en el firmware del ESP32, por ejemplo:
echo http://192.168.1.50:8080
echo.
ipconfig
echo.
pause
