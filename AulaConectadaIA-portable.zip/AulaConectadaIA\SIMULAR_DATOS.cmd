@echo off
setlocal
cd /d "%~dp0"

call "%~dp0tools\find_python.cmd"
if errorlevel 1 (
  pause
  exit /b 1
)

echo.
echo Enviando datos simulados al servidor local...
echo.

"%PYTHON_EXE%" server\simulate_events.py
echo.
echo Listo. Revisa el panel en http://localhost:8080
pause
