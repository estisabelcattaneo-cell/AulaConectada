@echo off
set "PYTHON_EXE="

where py >nul 2>nul
if not errorlevel 1 (
  for /f "delims=" %%P in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON_EXE=%%P"
)

if not defined PYTHON_EXE (
  where python >nul 2>nul
  if not errorlevel 1 set "PYTHON_EXE=python"
)

if not defined PYTHON_EXE (
  where python3 >nul 2>nul
  if not errorlevel 1 set "PYTHON_EXE=python3"
)

if not defined PYTHON_EXE (
  echo.
  echo No se encontro Python 3 en este computador.
  echo Instala Python desde https://www.python.org/downloads/
  echo Durante la instalacion marca la opcion "Add Python to PATH".
  echo.
  exit /b 1
)

exit /b 0
