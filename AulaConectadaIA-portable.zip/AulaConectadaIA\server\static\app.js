const connection = document.querySelector("#connection");
const studentsTable = document.querySelector("#studentsTable");
const eventsTable = document.querySelector("#eventsTable");
const gatewayList = document.querySelector("#gatewayList");
const refreshButton = document.querySelector("#refreshButton");
const classroomSelect = document.querySelector("#classroomSelect");
const activeClassroomLabel = document.querySelector("#activeClassroomLabel");
const setClassroomButton = document.querySelector("#setClassroomButton");
const newClassroomInput = document.querySelector("#newClassroomInput");
const addClassroomButton = document.querySelector("#addClassroomButton");

const summaryFields = {
  students: document.querySelector("#students"),
  present: document.querySelector("#present"),
  absent: document.querySelector("#absent"),
  common_zones: document.querySelector("#commonZones"),
};

function formatDate(value) {
  if (!value) return "Sin hora";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("es-CO", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    day: "2-digit",
    month: "2-digit",
  });
}

function statusClass(status) {
  if (status === "Presente en clase") return "present";
  if (status === "En zonas comunes") return "common";
  return "absent";
}

async function getJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Error ${response.status}`);
  return response.json();
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error(`Error ${response.status}`);
  return response.json();
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderSummary(summary) {
  summaryFields.students.textContent = summary.students ?? 0;
  summaryFields.present.textContent = summary.present ?? 0;
  summaryFields.absent.textContent = summary.absent ?? 0;
  summaryFields.common_zones.textContent = summary.common_zones ?? 0;
  activeClassroomLabel.textContent = summary.active_classroom ?? "Aula 10";
  document.querySelector("#lastUpdated").textContent = `Actualizado ${formatDate(summary.updated_at)}`;
}

function renderClassrooms(data) {
  const active = data.active_classroom ?? "Aula 10";
  classroomSelect.innerHTML = data.classrooms
    .map((classroom) => {
      const selected = classroom.name === active ? "selected" : "";
      return `<option value="${escapeHtml(classroom.name)}" ${selected}>${escapeHtml(classroom.name)}</option>`;
    })
    .join("");
  activeClassroomLabel.textContent = active;
}

function renderStudents(students) {
  studentsTable.innerHTML = students
    .map(
      (student) => `
        <tr>
          <td>${escapeHtml(student.name)}</td>
          <td>${escapeHtml(student.grade)}</td>
          <td>${escapeHtml(student.beacon_mac)}</td>
          <td>${escapeHtml(student.expected_zone)}</td>
        </tr>
      `
    )
    .join("");
}

function renderEvents(events) {
  eventsTable.innerHTML = events
    .map(
      (event) => `
        <tr>
          <td>${formatDate(event.observed_at)}</td>
          <td>${escapeHtml(event.student_name)}</td>
          <td><span class="badge ${statusClass(event.status)}">${escapeHtml(event.status)}</span></td>
          <td>${escapeHtml(event.zone)}</td>
          <td>${event.rssi ?? "N/A"}</td>
          <td>${Math.round((event.confidence ?? 0) * 100)}%</td>
          <td>${escapeHtml(event.source)}</td>
        </tr>
      `
    )
    .join("");
}

function renderGateways(gateways) {
  if (!gateways.length) {
    gatewayList.innerHTML = `<p class="muted">Todavia no hay ESP32 reportando.</p>`;
    return;
  }

  gatewayList.innerHTML = gateways
    .map(
      (gateway) => `
        <div class="gateway">
          <strong>${escapeHtml(gateway.gateway_id)}</strong>
          <span>${escapeHtml(gateway.zone)}</span>
          <span>IP: ${escapeHtml(gateway.ip ?? "N/A")}</span>
          <span>WiFi RSSI: ${gateway.wifi_rssi ?? "N/A"}</span>
          <span>Firmware: ${escapeHtml(gateway.firmware_version ?? "N/A")}</span>
          <span>Ultima señal: ${formatDate(gateway.last_seen)}</span>
        </div>
      `
    )
    .join("");
}

async function refresh() {
  try {
    const [summary, students, events, gateways, classrooms] = await Promise.all([
      getJson("/api/summary"),
      getJson("/api/students"),
      getJson("/api/events?limit=80"),
      getJson("/api/gateways"),
      getJson("/api/classrooms"),
    ]);

    renderSummary(summary);
    renderStudents(students);
    renderEvents(events);
    renderGateways(gateways);
    renderClassrooms(classrooms);
    connection.textContent = "Servidor activo";
  } catch (error) {
    connection.textContent = "Sin conexión con el servidor";
    console.error(error);
  }
}

async function applySelectedClassroom() {
  const classroom = classroomSelect.value;
  if (!classroom) return;
  await postJson("/api/settings/classroom", { classroom });
  await refresh();
}

async function addClassroom() {
  const name = newClassroomInput.value.trim();
  if (!name) return;
  await postJson("/api/classrooms", { name, activate: true });
  newClassroomInput.value = "";
  await refresh();
}

refreshButton.addEventListener("click", refresh);
setClassroomButton.addEventListener("click", applySelectedClassroom);
addClassroomButton.addEventListener("click", addClassroom);
newClassroomInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") addClassroom();
});
refresh();
setInterval(refresh, 5000);
