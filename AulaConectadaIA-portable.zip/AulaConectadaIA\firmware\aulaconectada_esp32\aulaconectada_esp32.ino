/*
  AulaConectada IA - Gateway ESP32

  Funciones:
  - Escanea beacons BLE asociados a estudiantes.
  - Clasifica la ubicacion segun RSSI y zona del gateway.
  - Envia eventos de asistencia al servidor local.
  - Activa LED/buzzer como confirmacion visual y sonora.

  Librerias requeridas en Arduino IDE:
  - ESP32 board support
  - BLEDevice incluida con ESP32
  - WiFi y HTTPClient incluidas con ESP32
*/

#include <BLEDevice.h>
#include <BLEScan.h>
#include <HTTPClient.h>
#include <WiFi.h>

const char* WIFI_SSID = "CAMBIAR_NOMBRE_WIFI";
const char* WIFI_PASSWORD = "CAMBIAR_CLAVE_WIFI";
const char* API_BASE_URL = "http://192.168.1.50:8080";

const char* GATEWAY_ID = "ESP32-AULA-10";
const char* DEFAULT_ZONE = "Aula 10";
const char* FIRMWARE_VERSION = "1.0.0";

const int LED_PIN = 2;
const int BUZZER_PIN = 15;
const int SCAN_SECONDS = 5;
const int PRESENT_RSSI = -68;
const int COMMON_ZONE_RSSI = -84;
const unsigned long LOOP_DELAY_MS = 10000;
const unsigned long HEARTBEAT_INTERVAL_MS = 30000;

struct StudentBeacon {
  const char* studentId;
  const char* name;
  const char* mac;
};

StudentBeacon STUDENTS[] = {
  {"EST-001", "Ana Sofia Banqueth Arias", "aa:bb:cc:10:00:01"},
  {"EST-002", "Isabel Sofia Caitaneo Contreras", "aa:bb:cc:10:00:02"},
  {"EST-003", "Adriana Moreno Hurtado", "aa:bb:cc:10:00:03"},
  {"EST-004", "Alejandro Martinez Machecha", "aa:bb:cc:10:00:04"},
  {"EST-005", "Greysis Nicole Torres Alvarado", "aa:bb:cc:10:00:05"}
};

const int STUDENT_COUNT = sizeof(STUDENTS) / sizeof(STUDENTS[0]);

BLEScan* bleScan;
unsigned long lastHeartbeat = 0;
String currentZone = DEFAULT_ZONE;

String escapeJson(const String& value) {
  String out = "";
  for (unsigned int i = 0; i < value.length(); i++) {
    char c = value.charAt(i);
    if (c == '"' || c == '\\') out += '\\';
    out += c;
  }
  return out;
}

void pulseConfirmation(bool present) {
  int pulses = present ? 2 : 1;
  for (int i = 0; i < pulses; i++) {
    digitalWrite(LED_PIN, HIGH);
    tone(BUZZER_PIN, present ? 1500 : 900, 120);
    delay(160);
    digitalWrite(LED_PIN, LOW);
    delay(100);
  }
}

void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Conectando WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print("IP asignada: ");
  Serial.println(WiFi.localIP());
}

String classifyStatus(int rssi) {
  if (rssi >= PRESENT_RSSI) return "Presente en clase";
  if (rssi >= COMMON_ZONE_RSSI) return "En zonas comunes";
  return "Ausente";
}

float confidenceFromRssi(int rssi) {
  if (rssi >= PRESENT_RSSI) return 0.92;
  if (rssi >= COMMON_ZONE_RSSI) return 0.68;
  return 0.35;
}

bool postJson(const String& path, const String& payload) {
  if (WiFi.status() != WL_CONNECTED) connectWifi();

  HTTPClient http;
  String url = String(API_BASE_URL) + path;
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  int statusCode = http.POST(payload);
  String response = http.getString();
  http.end();

  Serial.print("POST ");
  Serial.print(url);
  Serial.print(" -> ");
  Serial.println(statusCode);
  Serial.println(response);

  return statusCode >= 200 && statusCode < 300;
}

String getJson(const String& path) {
  if (WiFi.status() != WL_CONNECTED) connectWifi();

  HTTPClient http;
  String url = String(API_BASE_URL) + path;
  http.begin(url);
  int statusCode = http.GET();
  String response = http.getString();
  http.end();

  Serial.print("GET ");
  Serial.print(url);
  Serial.print(" -> ");
  Serial.println(statusCode);

  if (statusCode >= 200 && statusCode < 300) return response;
  return "";
}

String extractJsonString(const String& json, const String& key) {
  String pattern = "\"" + key + "\":";
  int keyIndex = json.indexOf(pattern);
  if (keyIndex < 0) return "";

  int firstQuote = json.indexOf("\"", keyIndex + pattern.length());
  if (firstQuote < 0) return "";

  int secondQuote = json.indexOf("\"", firstQuote + 1);
  if (secondQuote < 0) return "";

  return json.substring(firstQuote + 1, secondQuote);
}

void updateActiveClassroom() {
  String response = getJson("/api/settings");
  String apiZone = extractJsonString(response, "active_classroom");
  if (apiZone.length() > 0) {
    currentZone = apiZone;
  }

  Serial.print("Aula activa: ");
  Serial.println(currentZone);
}

void sendHeartbeat() {
  String payload = "{";
  payload += "\"gateway_id\":\"" + String(GATEWAY_ID) + "\",";
  payload += "\"zone\":\"" + escapeJson(currentZone) + "\",";
  payload += "\"ip\":\"" + WiFi.localIP().toString() + "\",";
  payload += "\"wifi_rssi\":" + String(WiFi.RSSI()) + ",";
  payload += "\"firmware_version\":\"" + String(FIRMWARE_VERSION) + "\"";
  payload += "}";

  postJson("/api/heartbeat", payload);
}

void sendAttendanceEvent(const StudentBeacon& student, int rssi) {
  String status = classifyStatus(rssi);
  float confidence = confidenceFromRssi(rssi);

  String payload = "{";
  payload += "\"student_id\":\"" + String(student.studentId) + "\",";
  payload += "\"student_name\":\"" + escapeJson(String(student.name)) + "\",";
  payload += "\"status\":\"" + status + "\",";
  payload += "\"zone\":\"" + escapeJson(currentZone) + "\",";
  payload += "\"rssi\":" + String(rssi) + ",";
  payload += "\"confidence\":" + String(confidence, 2) + ",";
  payload += "\"source\":\"BLE RSSI\",";
  payload += "\"gateway_id\":\"" + String(GATEWAY_ID) + "\"";
  payload += "}";

  bool ok = postJson("/api/events", payload);
  pulseConfirmation(ok && status == "Presente en clase");
}

int findStudentByMac(String mac) {
  mac.toLowerCase();
  for (int i = 0; i < STUDENT_COUNT; i++) {
    if (mac == STUDENTS[i].mac) return i;
  }
  return -1;
}

void scanAttendance() {
  Serial.println("Escaneando BLE...");
  BLEScanResults results = bleScan->start(SCAN_SECONDS, false);

  for (int i = 0; i < results.getCount(); i++) {
    BLEAdvertisedDevice device = results.getDevice(i);
    String mac = device.getAddress().toString().c_str();
    int studentIndex = findStudentByMac(mac);

    if (studentIndex >= 0) {
      int rssi = device.getRSSI();
      Serial.print("Detectado ");
      Serial.print(STUDENTS[studentIndex].name);
      Serial.print(" RSSI ");
      Serial.println(rssi);
      sendAttendanceEvent(STUDENTS[studentIndex], rssi);
    }
  }

  bleScan->clearResults();
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  connectWifi();
  BLEDevice::init("AulaConectada-Gateway");
  bleScan = BLEDevice::getScan();
  bleScan->setActiveScan(true);
  bleScan->setInterval(100);
  bleScan->setWindow(99);

  updateActiveClassroom();
  sendHeartbeat();
}

void loop() {
  if (millis() - lastHeartbeat > HEARTBEAT_INTERVAL_MS) {
    updateActiveClassroom();
    sendHeartbeat();
    lastHeartbeat = millis();
  }

  scanAttendance();
  delay(LOOP_DELAY_MS);
}
