from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DB_PATH = BASE_DIR / "aulaconectada.db"
DEFAULT_CLASSROOM = "Aula 10"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS students (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                grade TEXT NOT NULL,
                expected_zone TEXT NOT NULL DEFAULT 'Aula 10',
                beacon_mac TEXT NOT NULL UNIQUE,
                active INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS attendance_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL,
                student_name TEXT NOT NULL,
                status TEXT NOT NULL,
                zone TEXT NOT NULL,
                rssi INTEGER,
                confidence REAL NOT NULL,
                source TEXT NOT NULL,
                gateway_id TEXT NOT NULL,
                observed_at TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (student_id) REFERENCES students(id)
            );

            CREATE TABLE IF NOT EXISTS gateway_heartbeats (
                gateway_id TEXT PRIMARY KEY,
                zone TEXT NOT NULL,
                ip TEXT,
                wifi_rssi INTEGER,
                firmware_version TEXT,
                last_seen TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS classrooms (
                name TEXT PRIMARY KEY,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """
        )

        for classroom in (DEFAULT_CLASSROOM, "Pasillo principal", "Patio"):
            conn.execute(
                "INSERT OR IGNORE INTO classrooms (name, created_at) VALUES (?, ?)",
                (classroom, utc_now()),
            )

        conn.execute(
            "INSERT OR IGNORE INTO app_settings (key, value) VALUES ('active_classroom', ?)",
            (DEFAULT_CLASSROOM,),
        )

        count = conn.execute("SELECT COUNT(*) AS total FROM students").fetchone()["total"]
        if count == 0:
            conn.executemany(
                """
                INSERT INTO students (id, name, grade, expected_zone, beacon_mac)
                VALUES (?, ?, ?, ?, ?)
                """,
                [
                    ("EST-001", "Ana Sofia Banqueth Arias", "10A", DEFAULT_CLASSROOM, "AA:BB:CC:10:00:01"),
                    ("EST-002", "Isabel Sofia Caitaneo Contreras", "10A", DEFAULT_CLASSROOM, "AA:BB:CC:10:00:02"),
                    ("EST-003", "Adriana Moreno Hurtado", "10A", DEFAULT_CLASSROOM, "AA:BB:CC:10:00:03"),
                    ("EST-004", "Alejandro Martinez Machecha", "10A", DEFAULT_CLASSROOM, "AA:BB:CC:10:00:04"),
                    ("EST-005", "Greysis Nicole Torres Alvarado", "10A", DEFAULT_CLASSROOM, "AA:BB:CC:10:00:05"),
                ],
            )


def row_to_dict(row: sqlite3.Row) -> dict:
    return {key: row[key] for key in row.keys()}


def active_classroom(conn: sqlite3.Connection) -> str:
    row = conn.execute(
        "SELECT value FROM app_settings WHERE key = 'active_classroom'"
    ).fetchone()
    return row["value"] if row else DEFAULT_CLASSROOM


def save_classroom(conn: sqlite3.Connection, name: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO classrooms (name, created_at) VALUES (?, ?)",
        (name, utc_now()),
    )


class ApiHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def log_message(self, format: str, *args) -> None:
        print("[%s] %s" % (self.log_date_time_string(), format % args))

    def send_json(self, payload: object, status: int = 200) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8") if length else "{}"
        return json.loads(body or "{}")

    def do_OPTIONS(self) -> None:
        self.send_json({"ok": True})

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/students":
            self.get_students()
        elif parsed.path == "/api/events":
            self.get_events(parsed.query)
        elif parsed.path == "/api/summary":
            self.get_summary()
        elif parsed.path == "/api/gateways":
            self.get_gateways()
        elif parsed.path == "/api/classrooms":
            self.get_classrooms()
        elif parsed.path == "/api/settings":
            self.get_settings()
        else:
            super().do_GET()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/events":
            self.post_event()
        elif parsed.path == "/api/heartbeat":
            self.post_heartbeat()
        elif parsed.path == "/api/classrooms":
            self.post_classroom()
        elif parsed.path == "/api/settings/classroom":
            self.post_active_classroom()
        else:
            self.send_json({"error": "Ruta no encontrada"}, 404)

    def get_students(self) -> None:
        with connect() as conn:
            rows = conn.execute(
                "SELECT id, name, grade, expected_zone, beacon_mac, active FROM students ORDER BY name"
            ).fetchall()
        self.send_json([row_to_dict(row) for row in rows])

    def get_events(self, query: str) -> None:
        params = parse_qs(query)
        limit = min(int(params.get("limit", ["50"])[0]), 200)
        with connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM attendance_events
                ORDER BY created_at DESC, id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        self.send_json([row_to_dict(row) for row in rows])

    def get_summary(self) -> None:
        with connect() as conn:
            classroom = active_classroom(conn)
            students = conn.execute(
                """
                SELECT COUNT(*) AS total
                FROM students
                WHERE active = 1 AND expected_zone = ?
                """,
                (classroom,),
            ).fetchone()["total"]
            latest_rows = conn.execute(
                """
                SELECT e.*
                FROM attendance_events e
                INNER JOIN (
                    SELECT student_id, MAX(id) AS max_id
                    FROM attendance_events
                    GROUP BY student_id
                ) last_event ON last_event.max_id = e.id
                """
            ).fetchall()
            present = sum(
                1
                for row in latest_rows
                if row["status"] == "Presente en clase" and row["zone"] == classroom
            )
            common = sum(
                1
                for row in latest_rows
                if row["status"] == "En zonas comunes" and row["zone"] == classroom
            )
            absent = students - present - common
        self.send_json(
            {
                "active_classroom": classroom,
                "students": students,
                "present": present,
                "absent": max(absent, 0),
                "common_zones": common,
                "updated_at": utc_now(),
            }
        )

    def get_gateways(self) -> None:
        with connect() as conn:
            rows = conn.execute(
                "SELECT * FROM gateway_heartbeats ORDER BY last_seen DESC"
            ).fetchall()
        self.send_json([row_to_dict(row) for row in rows])

    def get_classrooms(self) -> None:
        with connect() as conn:
            classroom = active_classroom(conn)
            rows = conn.execute("SELECT name, created_at FROM classrooms ORDER BY name").fetchall()
        self.send_json(
            {
                "active_classroom": classroom,
                "classrooms": [row_to_dict(row) for row in rows],
            }
        )

    def get_settings(self) -> None:
        with connect() as conn:
            classroom = active_classroom(conn)
        self.send_json({"active_classroom": classroom})

    def post_event(self) -> None:
        try:
            data = self.read_json()
            required = ["student_id", "student_name", "status", "zone", "confidence", "source", "gateway_id"]
            missing = [field for field in required if field not in data]
            if missing:
                self.send_json({"error": "Campos faltantes", "fields": missing}, 400)
                return

            observed_at = data.get("observed_at") or utc_now()
            with connect() as conn:
                save_classroom(conn, data["zone"])
                conn.execute(
                    """
                    INSERT INTO attendance_events (
                        student_id, student_name, status, zone, rssi, confidence,
                        source, gateway_id, observed_at, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        data["student_id"],
                        data["student_name"],
                        data["status"],
                        data["zone"],
                        data.get("rssi"),
                        float(data["confidence"]),
                        data["source"],
                        data["gateway_id"],
                        observed_at,
                        utc_now(),
                    ),
                )
            self.send_json({"ok": True, "message": "Evento registrado"}, 201)
        except json.JSONDecodeError:
            self.send_json({"error": "JSON invalido"}, 400)
        except Exception as exc:
            self.send_json({"error": str(exc)}, 500)

    def post_heartbeat(self) -> None:
        try:
            data = self.read_json()
            gateway_id = data.get("gateway_id", "ESP32-AULA-10")
            with connect() as conn:
                zone = data.get("zone") or active_classroom(conn)
                save_classroom(conn, zone)
                conn.execute(
                    """
                    INSERT INTO gateway_heartbeats (
                        gateway_id, zone, ip, wifi_rssi, firmware_version, last_seen
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(gateway_id) DO UPDATE SET
                        zone = excluded.zone,
                        ip = excluded.ip,
                        wifi_rssi = excluded.wifi_rssi,
                        firmware_version = excluded.firmware_version,
                        last_seen = excluded.last_seen
                    """,
                    (
                        gateway_id,
                        zone,
                        data.get("ip"),
                        data.get("wifi_rssi"),
                        data.get("firmware_version", "dev"),
                        utc_now(),
                    ),
                )
            self.send_json({"ok": True, "message": "Gateway actualizado"})
        except Exception as exc:
            self.send_json({"error": str(exc)}, 500)

    def post_classroom(self) -> None:
        try:
            data = self.read_json()
            name = str(data.get("name", "")).strip()
            if not name:
                self.send_json({"error": "El nombre del aula es obligatorio"}, 400)
                return

            with connect() as conn:
                save_classroom(conn, name)
                if data.get("activate"):
                    conn.execute(
                        """
                        INSERT INTO app_settings (key, value)
                        VALUES ('active_classroom', ?)
                        ON CONFLICT(key) DO UPDATE SET value = excluded.value
                        """,
                        (name,),
                    )
                    conn.execute(
                        "UPDATE students SET expected_zone = ? WHERE active = 1",
                        (name,),
                    )
                classroom = active_classroom(conn)
            self.send_json({"ok": True, "message": "Aula guardada", "active_classroom": classroom})
        except Exception as exc:
            self.send_json({"error": str(exc)}, 500)

    def post_active_classroom(self) -> None:
        try:
            data = self.read_json()
            name = str(data.get("classroom", "")).strip()
            if not name:
                self.send_json({"error": "El aula activa es obligatoria"}, 400)
                return

            with connect() as conn:
                save_classroom(conn, name)
                conn.execute(
                    """
                    INSERT INTO app_settings (key, value)
                    VALUES ('active_classroom', ?)
                    ON CONFLICT(key) DO UPDATE SET value = excluded.value
                    """,
                    (name,),
                )
                conn.execute(
                    "UPDATE students SET expected_zone = ? WHERE active = 1",
                    (name,),
                )
            self.send_json({"ok": True, "message": "Aula activa actualizada", "active_classroom": name})
        except Exception as exc:
            self.send_json({"error": str(exc)}, 500)


def main() -> None:
    init_db()
    server = ThreadingHTTPServer(("0.0.0.0", 8080), ApiHandler)
    print("AulaConectada IA disponible en http://localhost:8080")
    server.serve_forever()


if __name__ == "__main__":
    main()
